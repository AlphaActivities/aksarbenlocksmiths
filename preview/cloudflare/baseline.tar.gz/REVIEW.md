# Aksarben staff review

Build the selected premium-dashboard revision with npm run build:ci in its checkout, then run python build-review.py /absolute/path/to/checkout here. The HTML embeds the Git revision. The Site has an independent publication step.

The dashboard modules and CSS are copied byte for byte from the build. The review worker serves synthetic, read-only staff fixtures behind ChatGPT authentication. Its HTML adds a footer after the application, includes the credentialed standalone manifest and its icons, omits Apple startup links, and its CSP disables service workers. The review film is a smaller encode of the same 57-second source. The production build retains its original media, manifest, startup images, service worker and CRM authentication. A review on a phone verifies browser presentation. Installed production-build PWA acceptance requires a separate physical check.
