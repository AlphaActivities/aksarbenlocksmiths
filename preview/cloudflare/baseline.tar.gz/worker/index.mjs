import { assets } from "./assets.mjs";

import { fixture } from "./fixtures.mjs";

const dashboardRoute = /^\/admin\/(?:queue|reset-password|history|reports|settings|notifications|calls|business|leads\/[a-f0-9-]{36})\/?$/i;

function reply(status, code) {
  return Response.json({ error: code }, {
    status,
    headers: { "Cache-Control": "no-store, private", "X-Content-Type-Options": "nosniff" },
  });
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    if (!request.headers.get("oai-authenticated-user-id")) return reply(401, "sign_in_required");

    if (request.method !== "GET" && request.method !== "HEAD") return reply(405, "method_not_allowed");
    if (url.pathname.startsWith("/api/crm/")) {
      const body = fixture(url);
      return body ? Response.json(body, {headers: {"Cache-Control":"private, no-store"}}) : reply(404, "not_found");
    }
    if (url.pathname === "/") return Response.redirect(new URL("/admin/", url), 302);
    const staticPath = dashboardRoute.test(url.pathname) ? "/admin/index.html" : url.pathname;
    const item = assets[staticPath] || assets[staticPath.replace(/\/$/, "") + "/index.html"];
    if (!Array.isArray(item)) return reply(404, "not_found");
    const [contentType, data] = item;
    if (contentType === "video/mp4") {
      const bytes = Uint8Array.fromBase64 ? Uint8Array.fromBase64(data) : Uint8Array.from(atob(data), char => char.charCodeAt(0));
      const headers = {"Content-Type": contentType, "Accept-Ranges": "bytes", "Cache-Control": "private, max-age=3600"};
      const range = request.headers.get("range");
      if (!range) return new Response(request.method === "HEAD" ? null : bytes, {headers: {...headers, "Content-Length": String(bytes.length)}});
      const match = /^bytes=(\d+)-(\d*)$/.exec(range);
      const start = Number(match?.[1]), end = match?.[2] ? Math.min(Number(match[2]), bytes.length - 1) : bytes.length - 1;
      if (!match || start > end) return new Response(null, {status: 416, headers: {...headers,"Content-Range": "bytes */" + bytes.length}});
      return new Response(request.method === "HEAD" ? null : bytes.subarray(start,end + 1), {
        status: 206, headers: {...headers, "Content-Range": "bytes " + start + "-" + end + "/" + bytes.length, "Content-Length": String(end-start+1)}
      });
    }
    return new Response(request.method === "HEAD" ? null : Uint8Array.from(atob(data), char => char.charCodeAt(0)), {
      headers: {
        "Content-Type": contentType,
        "Content-Security-Policy": "default-src 'self'; connect-src 'self'; worker-src 'none'; style-src 'self' 'unsafe-inline'; object-src 'none'; form-action 'none'; base-uri 'none'",
        "Cache-Control": "no-store, private",
        "X-Content-Type-Options": "nosniff",
      },
    });
  },
};

