// Read-only fixtures served only by the access-controlled review Site.
const examples = [
  ["Residential", "urgent", "new", "Synthetic lockout"],
  ["Automotive", "scheduled", "scheduled", "Synthetic follow-up"],
  ["Commercial", "quote", "history", "Synthetic archive"],
];
const leads = examples.map(([service, urgency, status, name], index) => ({
  id: "10000000-0000-4000-8000-00000000000" + (index + 1), name,
  phone: "+1402555010" + index, email: "review@example.invalid", area: "Omaha",
  service, urgency, status, source: "manual", version: 1, historical: index === 2,
  created_at: "2026-11-21T12:00:00Z", follow_up_at: index === 1 ? "2026-11-21T15:00:00Z" : null,
  message: "Synthetic example for dashboard review.", conversation_state: "bot", assigned_to: null, conversation: [],
}));
const active = leads.slice(0, 2).map((lead, i) => ({
  id: lead.id, lead_id: lead.id, name: lead.name, urgent: !i,
  occurred_at: lead.created_at, category: i ? "follow_up" : "inquiry", title: i ? "Scheduled follow-up" : "Urgent callback",
}));
export function fixture(url) {
  const path = url.pathname.slice("/api/crm/".length);
  if (path === "session") return {role: "staff", user_id: leads[0].id, email: "review@example.invalid"};
  if (path === "attention") return {attention: active.length};
  if (path === "notifications") return {attention: active.length, active, history: []};
  if (path === "queue") {
    const service = url.searchParams.get("service"), from = url.searchParams.get("from"), to = url.searchParams.get("to");
    const filtered = leads.filter(row => (!service || row.service === service) && (!from || Date.parse(row.created_at) >= Date.parse(from)) && (!to || Date.parse(row.created_at) < Date.parse(to)));
    return {attention: active.length, leads: filtered, metrics: {inquiry_confirmed: filtered.filter(row => !row.historical).length, booked: 0, callback_completed: 0}};
  }
  if (path === "calls") return {connected: false, calls: [
    { provider_call_id: "review.1", occurred_at: "2026-11-21T15:00:00Z",
      caller_phone: leads[0].phone, business_did: "+15315550190", disposition: "ANSWERED",
      duration_seconds: 34, historical: true, related_lead_id: leads[0].id },
    { provider_call_id: "review.2", occurred_at: "2026-11-21T13:00:00Z",
      caller_phone: "+14025550191", business_did: "+15315550192", disposition: "NO ANSWER",
      duration_seconds: 0, historical: true, related_lead_id: null },
  ]};
  if (path === "settings") return {preferences: {inquiries:true,handoffs:true,follow_ups:true}, devices:[],receipts:[],push_enabled:false,vapid_public_key:null};
  const lead = leads.find(row => path === "leads/" + row.id);
  if (lead) return {lead, events: []};
}
