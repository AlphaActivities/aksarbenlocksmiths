"""Package an already-built admin entry from the specified development checkout."""
from pathlib import Path
import base64, json, re, subprocess, sys, tempfile
root = Path(sys.argv[1]).resolve()
build = root / "dist"
revision = subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], text=True).strip()
html = (build / "admin/index.html").read_text()
html = re.sub(r'<link\s+rel="apple-touch-startup-image".*?/>', '', html, flags=re.S)
html = html.replace('rel="manifest"', 'rel="manifest" crossorigin="use-credentials"')
html = html.replace('</head>', '<meta name="review-commit" content="' + revision + '"></head>')
html = html.replace("</body>", '<footer style="position:relative;z-index:1;padding:6px;background:#172442;color:white;text-align:center;font:14px system-ui">Staff review · Synthetic records · Read-only</footer></body>')
def asset(kind, data):
    return [kind, base64.b64encode(data).decode()]
assets = {"/admin/index.html":asset("text/html; charset=utf-8",html.encode())}
types = {".webmanifest":"application/manifest+json",".js":"text/javascript",".css":"text/css",".png":"image/png",".webp":"image/webp"}
for path in set(re.findall(r'(?:src|href)="(/[^"]+)"',html)):
    file = build / path[1:]
    assets[path] = asset(types[file.suffix],file.read_bytes())
manifest = json.loads((build / "admin/manifest.webmanifest").read_text())
# Start inside the directory used by every dashboard section.
manifest.update(start_url="/admin/", scope="/admin")
assets["/admin/manifest.webmanifest"] = asset("application/manifest+json", json.dumps(manifest).encode())
for icon in manifest["icons"]:
    path = icon["src"]
    assets[path] = asset("image/png", (build / path.lstrip("/")).read_bytes())
assets["/images/poster.webp"] = asset("image/webp", (build/"images/poster.webp").read_bytes())
# Use Mike's complete film at a lower bitrate for the size-limited review worker.
with tempfile.TemporaryDirectory() as directory:
    target = Path(directory)/"review.mp4"
    subprocess.run(["ffmpeg","-loglevel","error","-i",str(build/"videos/wallpaper.mp4"),
                    "-vf","scale=320:-2,fps=15","-an","-c:v","libx264","-threads","2",
                    "-crf","30","-maxrate","180k","-bufsize","360k","-movflags","+faststart",str(target)],check=True)
    assets["/videos/wallpaper.mp4"] = asset("video/mp4",target.read_bytes())
Path("worker/assets.mjs").write_text("export const assets = "+json.dumps(assets)+";\n")
subprocess.run([root/"node_modules/.bin/esbuild","worker/index.mjs","--bundle","--format=esm","--outfile=dist/server/index.js"],check=True)
